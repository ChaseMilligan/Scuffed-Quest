==============================================================================

Hey!!!!!

Thank you for downloading my little asset pack <3


You can use this asset anywhere, giving credit to me would be appreciated!
If you really like this asset and want more of these to be made in the future,
a small donation on my itch page is a big motivation! uwu

-Trix

==============================================================================
